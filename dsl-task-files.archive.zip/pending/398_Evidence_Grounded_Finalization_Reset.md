# Task 398: Evidence Grounded Finalization Reset

**Status:** pending
**Priority:** high
**Depends on:** Task 391, Task 395

## Summary

Make final answers robust after tool loops, repair loops, and stop-policy termination by using a clean finalization context that contains user intent, executed evidence, unresolved risks, and no stale action markup.

## Session Evidence

- Several sessions ended with generic failure text after invalid DSL with no clear recovery path.
- Older sessions show final answers claiming success or providing commands without matching executed tool evidence.
- Some turn-summary reasoning hallucinated actions that did not execute, especially around deletion and shell commands.

## Scope

- Add a finalization input builder that includes only: raw user request, compact intent, route, executed tool summaries, artifact paths, stop reason, and unresolved blockers.
- Reject or retry final answers that contain action markup, provider tags, or claims of executed work not present in the evidence ledger.
- Add a deterministic fallback answer from evidence when finalizer output is empty or markup-like.
- Persist finalization source rows in transcript/session artifacts.

## Non-Goals

- Do not ask the action model to also write the final answer during unstable repair loops.
- Do not rely on chain-of-thought text as evidence.
- Do not modify `src/prompt_core.rs`.

## Success Criteria

- [ ] Final answers cannot claim a command ran unless a shell/read/search/edit evidence entry exists.
- [ ] Stop-policy fallback answers include the stop reason and the best available evidence.
- [ ] Action markup in finalizer output triggers a clean-context retry or deterministic evidence summary.

## Verification

```bash
cargo test --bin elma-cli evidence_ledger
cargo test --bin elma-cli tool_loop
cargo test --bin elma-cli final
```
