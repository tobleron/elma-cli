# Task 396: Llama 3.2 Fast DSL Profile Certification

**Status:** pending
**Priority:** critical
**Depends on:** Task 385, Task 387, Task 392, Task 393

## Summary

Create a fast development profile and certification path for `llama_3.2_3b_instruct_q6_k_l.gguf`, optimized for dense non-thinking DSL output while preserving thinking-model support for future profiles.

## Scope

- Restore or create the active Llama 3.2 profile without deleting disabled historical profile files.
- Configure `reasoning_format=none` for dense profile action/intel units.
- Ensure grammar mappings exist for all migrated DSL units used by the basic smoke pack.
- Add a model capability flag that distinguishes dense non-thinking, separated-thinking, and mixed-thinking models.
- Make smoke harness output compare Llama 3.2 results against the current Huihui/Qwen profile.

## Non-Goals

- Do not remove thinking-model code paths.
- Do not force all models to use the Llama 3.2 prompt profile.
- Do not change `src/prompt_core.rs`.

## Success Criteria

- [ ] Llama 3.2 can run the basic `_testing_prompts/` pack without model-output JSON.
- [ ] Thinking-capable profiles still preserve separated reasoning when enabled.
- [ ] The fast profile produces action DSL or accepted provider-boundary markup for shell/list/read/search smoke prompts.
- [ ] Certification fails if any migrated intel unit falls back from invalid DSL.

## Verification

```bash
cargo test --bin elma-cli model_capabilities
cargo test --bin elma-cli dsl
cargo run -- --debug-trace
```

## Current Verification Notes

- Llama 3.2 dense non-thinking profile tests pass and live prompts reach the configured local endpoint.
- `hi` and list-directory prompts now complete with visible route/evidence behavior.
- Remaining blocker: the basic smoke pack is not fully stable. Search/read does not perform the read step, and shell/list still stops after repeated malformed action DSL.
