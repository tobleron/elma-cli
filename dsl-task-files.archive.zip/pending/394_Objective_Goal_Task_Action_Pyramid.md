# Task 394: Objective Goal Task Action Pyramid

**Status:** pending
**Priority:** high
**Depends on:** Task 380, Task 393

## Summary

Introduce an explicit decomposition pyramid for hard requests: objective -> goal -> task list -> next action. The purpose is to keep small local models accurate by narrowing each decision instead of asking one tool-loop turn to infer everything.

## Scope

- Add compact DSL units for:
  - `OBJECTIVE text="..." risk=low|medium|high`
  - `GOAL text="..." evidence_needed=true|false`
  - `TASK id=1 text="..." status=pending`
  - `NEXT task_id=1 action=read|list|search|shell|edit|ask|done`
- Use the pyramid only when routing confidence, evidence need, or prior repair failures indicate that direct action selection is unstable.
- Store the pyramid in transcript-native collapsible rows and session metadata.
- Feed only the current objective, active goal, and next task into the action loop to keep context compact.

## Non-Goals

- Do not replace the fast direct action path for simple requests.
- Do not turn decomposition into a giant prompt.
- Do not use JSON as model output.

## Success Criteria

- [ ] Complex requests create visible objective/goal/task rows before tool execution.
- [ ] Simple chat and simple read/list requests bypass the pyramid.
- [ ] Repair loops can fall back from action generation to `NEXT` selection.
- [ ] Session replay shows semantic continuity from user request to final answer.

## Verification

```bash
cargo test --bin elma-cli decomposition
cargo test --bin elma-cli orchestration
```

## Current Verification Notes

- Pyramid data types, DSL parsing, narrative builders, and visibility hooks exist and unit tests pass.
- Live smoke exposed `intel_decomposition_execute_failed error=URL error: relative URL without a base`.
- Repair loops do not yet execute a true `NEXT` selector fallback, so this remains pending.
