# Task 387: Intel DSL Profile Repair And Live Smoke Gate

**Status:** pending
**Priority:** critical
**Depends on:** Task 380, Task 381, Task 384, Task 385

## Summary

Live smoke shows the action DSL path can execute and display basic tool rows, but migrated intel units still sometimes produce prose instead of strict DSL. Deterministic fallback keeps the UI from failing, but it is not good enough for DSL certification because the basic prompt path still depends on fallback for `evidence_need_assessor` and `turn_summary`.

## Scope

- Add per-profile live-smoke assertions for migrated intel units used by basic prompts: speech act, workflow gate, workflow mode, evidence needs, and turn summary.
- Make a basic smoke run fail certification if any migrated intel unit reaches deterministic fallback due to `INVALID_DSL`.
- Tighten the affected profile prompts, request options, grammar mapping, and repair observations without modifying `src/prompt_core.rs`.
- Reduce the cognitive load of `evidence_need_assessor` and `turn_summary` inputs so each unit makes one narrow decision and emits one compact DSL command.
- Persist first-attempt and repair-attempt parser previews in trace artifacts for failed intel units.
- Keep deterministic fallbacks as runtime safety, but mark them as non-passing for DSL certification.

## Non-Goals

- Do not return to JSON model output.
- Do not add semantic keyword routing.
- Do not modify `src/prompt_core.rs` or `TOOL_CALLING_SYSTEM_PROMPT`.
- Do not solve advanced file context tracking, protected-path policy, patch application, browser, or network fetch work here.

## Success Criteria

- [ ] `hi` returns a natural plain-text chat answer with no workflow-success phrasing.
- [ ] Top-level list smoke emits a visible `list path=. depth=1` row and returns gathered evidence.
- [ ] Basic search/read smoke emits visible tool rows and returns gathered evidence.
- [ ] No migrated intel unit in the basic smoke pack falls back due to `INVALID_DSL`.
- [ ] Trace artifacts identify the exact profile and parser error for any failed DSL attempt.
- [ ] No model-produced JSON contract is introduced.

## Verification

```bash
cargo fmt --check
cargo test dsl
cargo test ui_chat::tests
cargo test executor_contract_tests -- --test-threads=1
cargo run -- --debug-trace
```

Manual smoke should run the basic `_testing_prompts/` pack and record session paths in Task 385.
