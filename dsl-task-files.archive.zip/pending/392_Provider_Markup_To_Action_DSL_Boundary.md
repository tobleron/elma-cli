# Task 392: Provider Markup To Action DSL Boundary

**Status:** pending
**Priority:** critical
**Depends on:** Task 378, Task 391

## Summary

Complete the boundary adapter that converts provider-native or model-leaked tool markup into Rust-native `AgentAction` values before the tool loop runs. The compact DSL remains canonical, but Elma should not fail only because a model emits a familiar provider wrapper.

## Current State

- The action parser now accepts exact `<tool_call>{...}</tool_call>` content.
- The action parser now accepts exact `<command>...</command>` content, mapping shell command bodies to `X` and native DSL bodies to the wrapped action.
- The action normalizer now strips reasoning while preserving provider tool markup long enough to parse it.

## Remaining Scope

- Convert provider-native `ChatMessage.tool_calls` into `AgentAction` instead of ignoring them when `tools: None` was requested but the server still returns tool-call fields.
- Add a transcript row that says provider markup was normalized into action DSL, with the normalized action hidden in a collapsible detail row.
- Reject mixed prose plus tool markup deterministically, with a repair observation that asks for native action DSL.
- Add strict tests for exact accepted shapes and rejected mixed shapes.

## Non-Goals

- Do not restore provider-native tool execution as the main path.
- Do not expand into a general XML parser.
- Do not accept arbitrary tags or nested markup beyond documented provider compatibility wrappers.

## Success Criteria

- [ ] Exact provider markup maps to `AgentAction`.
- [ ] Provider-native `tool_calls` maps to the same `AgentAction` execution path as text DSL.
- [ ] Mixed prose plus provider markup is rejected and repaired, not extracted.
- [ ] The transcript shows normalization happened without hiding it in trace-only logs.

## Verification

```bash
cargo test --bin elma-cli dsl
cargo test --bin elma-cli tool_loop
```

## Current Verification Notes

- Exact `<tool_call>`, `<command>`, bare tool-call JSON, and provider-native `tool_calls` adapters are implemented and covered by passing DSL tests.
- Remaining blocker: provider normalization still needs a dedicated transcript notice row instead of only generic tool trace rows, and live smoke still shows non-provider malformed action recovery gaps.
