# Task 399: Prompt Core DSL Rewrite Review Gate

**Status:** pending
**Priority:** critical
**Depends on:** None (observes the uncommitted prompt_core.rs change)

## Context

The last uncommitted work session modified `src/prompt_core.rs` (~85 lines diff), rewriting the `TOOL_CALLING_SYSTEM_PROMPT` from a tool-calling pipeline prompt to a DSL-only action pipeline prompt.

AGENTS.md Rule 9 states:

> **You must NEVER modify `src/prompt_core.rs` or `TOOL_CALLING_SYSTEM_PROMPT` without explicit user approval.**

This task gates that change for review.

## What Changed

The old prompt (~100 tokens, tool-calling focused):
- Identity + "take action" + "deliver direct answers"
- Tool workflow: discover → execute → respond → summary
- Evidence-grounding principle
- No DSL commands in the prompt itself

The new prompt (DSL-only focus):
- Identity + "emit exactly one DSL command per turn"
- Lists specific DSL commands (R, L, S, Y, E, ...OLD/...NEW)
- Inline documentation of edit format
- No mention of respond/summary/update_todo_list tools
- No "direct answers for conversational queries" fallback path

## Scope

1. Present the prompt_core.rs diff to the user for explicit approval
2. Verify the new prompt still handles:
   - Simple conversational queries ("hi", "what's up") through the DSL path
   - Complex multi-step tasks through the DSL tool loop
   - Evidence-gathered final answers via DONE
   - Fallback when the model produces invalid DSL or prose
3. Run the basic smoke pack (`_testing_prompts/`) against the new prompt
4. If approved: mark gate as passed, commit with attribution
5. If rejected: restore the prompt from the commit version and find a less invasive way to add DSL guidance (e.g., injected context, not prompt rewrite)

## Non-Goals

- Do not change the DSL action parser, executor, or grammar.
- Do not add examples or JSON output paths.
- Do not modify any other file in this task.

## Success Criteria

- [ ] User has reviewed and approved the prompt_core.rs diff
- [ ] Basic conversational queries still work (including "hi", "what is this project")
- [ ] DSL tool loop still works for multi-step tasks
- [ ] Final answers are evidence-grounded
- [ ] Invalid DSL falls back gracefully
- [ ] `cargo test` passes
- [ ] No regression in any scenario smoke test

## Verification

```bash
cargo build
cargo test
cargo run -- --debug-trace
# Manual: run basic smoke prompts
```
