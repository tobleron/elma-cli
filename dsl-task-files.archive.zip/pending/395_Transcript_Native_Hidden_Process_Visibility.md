# Task 395: Transcript Native Hidden Process Visibility

**Status:** pending
**Priority:** high
**Depends on:** Task 385, Task 391

## Summary

Surface routing, DSL repair, compaction, stop reasons, and provider-markup normalization as collapsible transcript rows. This implements the AGENTS.md rule that the transcript is the single source of truth for what happened.

## Session Evidence

- Many sessions expose important facts only in `trace_debug.log`, including route choices, fallback status, parser failures, and stop reasons.
- Final answers such as "I could not continue because the model repeatedly produced invalid action DSL" do not show the exact failed outputs in the user-visible transcript.

## Scope

- Add transcript row types for `route_decision`, `dsl_repair`, `provider_markup_normalized`, `compaction`, `stop_reason`, and `fallback_used`.
- Keep the bottom status bar limited to model name, token count, and elapsed time.
- Persist rows in `artifacts/terminal_transcript.txt` and display them in the TUI as collapsed by default.
- Include parser error code, unit name, and bounded preview for repair rows.

## Non-Goals

- Do not dump full model output or private reasoning into visible transcript rows.
- Do not make trace logging the primary UX.

## Success Criteria

- [ ] Invalid DSL repair appears in the terminal transcript with error code and bounded preview.
- [ ] Stop-policy termination appears as a transcript row with reason and counters.
- [ ] Compaction appears as a transcript row with before/after token estimates.
- [ ] Footer remains limited to model, token count, and elapsed time.

## Verification

```bash
cargo test --bin elma-cli ui_trace
cargo test --bin elma-cli stop_policy
cargo run -- --debug-trace
```

## Current Verification Notes

- Route rows now appear in both direct chat and tool-loop paths.
- DSL repair and stop reason rows appeared in live transcripts.
- Remaining blocker: `cargo test --bin elma-cli ui_trace` currently runs zero tests, and provider-normalization/compaction row coverage still needs explicit transcript tests.
