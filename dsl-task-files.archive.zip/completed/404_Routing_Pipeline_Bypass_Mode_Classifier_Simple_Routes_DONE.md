# Task 404: Routing Pipeline Audit — Bypass Mode Classifier For Simple Routes

**Status:** pending
**Priority:** high
**Depends on:** T401, Task 400

## Summary

The 3-stage routing pipeline (speech_act → workflow_gate → mode_router) has 3 chances to fail, and the mode classifier is the weakest link. For simple cases where the route is already clear after 2 stages, bypass the mode classifier entirely. This reduces failure surface without removing the mode classifier for complex cases that need it.

## Analysis

Current pipeline:
```
speech_act → workflow_gate → mode_router → route_decision
   (3 labels)    (2 labels)     (5 labels)
```

Each stage can fail independently. When mode_router fails (`dsl_parse_failed`), the whole pipeline often degrades to `conservative_chat_fallback` even when speech_act correctly identified INSTRUCT and workflow_gate correctly identified WORKFLOW.

Observed in all 3 sessions: speech_act=INSTRUCT, workflow_gate=WORKFLOW, mode=dsl_parse_failed → CHAT fallback. The mode classifier failure erases the correct routing from the earlier stages.

## Scope

1. **Bypass rule**: When speech_act confidence is high (entropy < 0.3) AND workflow_gate chooses WORKFLOW with high margin (> 0.3), skip the mode classifier and route directly to EXECUTE (use evidence needs classifier to decide tool loop vs finalize).

2. **When to keep mode classifier**: Keep the full pipeline for:
   - Low-confidence speech_act (entropy ≥ 0.3)
   - CHAT route from workflow_gate (mode classifier adds no value here either — could skip)
   - WORKFLOW route with unclear scope (the mode classifier's PLAN/MASTERPLAN/DECIDE distinction)

3. **Route decision source annotation**: When the mode classifier is bypassed, annotate the route decision source as `"direct_2stage"` instead of `"mode:dsl_parse_failed"` so transcript visibility accurately reflects the decision path.

4. **Conservative fallback protection**: If mode classifier IS called and fails, preserve the workflow_gate route instead of falling back to CHAT. A mode classifier failure should mean "proceed with EXECUTE as safe default" not "abandon the workflow route."

## Non-Goals

- Do not remove the mode classifier or its GBNF grammar.
- Do not replace the 3-stage pipeline wholesale.
- Do not modify `src/prompt_core.rs`.

## Success Criteria

- [ ] High-confidence INSTRUCT+WORKFLOW routes skip mode classifier and proceed to EXECUTE
- [ ] Mode classifier failure does NOT cause fallback to CHAT when workflow_gate chose WORKFLOW
- [ ] Route decision source shows `direct_2stage` when mode classifier is bypassed
- [ ] Low-confidence or CHAT routes still use full pipeline
- [ ] `cargo test routing_infer` passes

## Verification

```bash
cargo test --bin elma-cli routing_infer
cargo run -- --debug-trace
# Manual: verify "ls current directory" bypasses mode classifier and reaches tool loop
```
