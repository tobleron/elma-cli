# Task 415: Action DSL Format Specialist Intel Unit

**Status:** pending
**Priority:** critical
**Depends on:** Task 414

## Summary

3B models frequently produce invalid action DSL. The most common failure: unquoted paths (`R /Users/r2/elma-cli` instead of `R path="/Users/r2/elma-cli"`). The model knows what action to take but cannot format the DSL correctly.

Create a dedicated intel unit whose ONLY job is to format a given decision into exact action DSL syntax. The decision unit decides "what to do" (action type, target path, arguments). The format unit formats "how to say it" (exact DSL with quoted paths, correct field names, proper whitespace).

## Scope

- Add `ActionDslFormatter` intel unit with prompt: "Given the action decision below, emit exactly one valid action DSL line."  
- Input: action type (R, L, S, Y, X, E), path/query, optional arguments. Created from the existing action decision path.
- Output: exactly one valid action DSL line like `R path="/path"` or `L path="/dir" depth=1`.
- Replace the current single-step model call (decide AND format) with two calls: first decides the action type, second formats it into DSL.
- Wire GBNF grammar that constrains output to valid action DSL tokens.
- The format specialist must never produce prose, explanations, or multi-line output.

## Non-Goals

- Do not change the action DSL grammar or parser.
- Do not add JSON or any alternative format.
- Do not modify src/prompt_core.rs.

## Success Criteria

- [ ] Action DSL produced by the format specialist parses without INVALID_DSL on 3B models.
- [ ] Unquoted path errors drop to zero for basic shell/list/read/search prompts.
- [ ] The format specialist produces consistent output across different action types.
- [ ] GBNF grammar prevents prose/free-text output from the formatter.

## Verification

```bash
cargo build
cargo test dsl
cargo test intel_units
cargo test tool_loop
cargo run -- --debug-trace
```
