# Task 406: Fix ad_hoc_profile Empty base_url Causing Decomposition Crash

**Status:** completed
**Priority:** critical
**Depends on:** none

## Summary

The decomposition intel unit crashes with `IntelError::Url: URL error: relative URL without a base` because `ad_hoc_profile()` in `src/llm_config.rs:145` sets `base_url: String::new()` (empty string). When the decomposition unit calls `intel_chat_url()` at `src/intel_trait.rs:388`, it calls `Url::parse("")` which fails.

Live session evidence: `trace_debug.log` shows `[INTEL_VERBOSE] intel_decomposition_execute_failed error=URL error: relative URL without a base`.

## Root Cause

`src/llm_config.rs:140-155` — `ad_hoc_profile()` creates a lightweight profile with an empty `base_url` field. Intel units that use this profile need `base_url` populated to construct the LLM API endpoint URL.

## Scope

- In `src/llm_config.rs`, populate `base_url` in `ad_hoc_profile()` from the active saved-config profile, or fall back to a reasonable default.
- Ensure the decomposition unit (`src/intel_units/intel_units_pyramid.rs`) can reach the LLM API after the fix.
- Add a guard in `intel_chat_url()` in `src/intel_trait.rs` to return a clear error early if `base_url` is empty, rather than letting `Url::parse` produce an opaque error.

## Non-Goals

- Do not refactor the entire profile system.
- Do not change how the decomposition unit generates its output format.

## Success Criteria

- [ ] `ad_hoc_profile()` produces a profile with a valid `base_url`.
- [ ] Decomposition unit can execute without URL parse errors.
- [ ] Empty base_url is caught early with a clear error message.

## Verification

```bash
cargo build
cargo test llm_config
cargo test intel_trait
```
