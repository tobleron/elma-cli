# Task 386: DSL Action Command Timeouts And Output Budgets

**Status:** completed
**Priority:** high
**Depends on:** Task 379

## Summary

Add explicit timeout and output-budget enforcement to every compact DSL action executor, especially `X`, `S`, and `Y`. The model should never be able to stall the UI or flood the context through an unbounded command/search result.

## Scope

- Wrap `X` command execution in a real timeout with transcript-visible timeout status.
- Wrap `S` and `Y` search execution in a timeout and deterministic truncation budget.
- Preserve full large outputs in session artifacts when useful, while keeping model context compact.
- Return compact repair observations for timeout, unsafe command, path failure, and output overflow cases.
- Add regression tests for timeout, huge output, no match, command failure, and successful output.

## Success Criteria

- [x] A long-running allowed command is killed and shown as timed out.
- [x] Large search output is truncated for model context and persisted when configured.
- [x] Timeout and truncation details appear in transcript-native tool rows.
- [x] No executor uses shell-string interpolation for search.

## Changes

### `src/dsl/safety.rs`

**New `validate_command` function** (extracted from `execute_command_policy`):
- Pure validation without execution — checks empty, control chars, shell operators, allowlist
- Shared between sync and async execution paths
- Returns parsed `Vec<String>` on success

**New `execute_command_policy_async` function**:
- Async version using `tokio::process::Command` with `kill_on_drop(true)`
- Wraps execution in `tokio::time::timeout` (configurable, default 30s)
- Returns compact repair observation on timeout or execution failure
- Sets `timed_out = true` in the result on timeout

**New constant `DEFAULT_COMMAND_TIMEOUT_SECS`**: 30 seconds

**Refactored `execute_command_policy`**:
- Now delegates to shared `validate_command` — behavior unchanged

### `src/tool_loop.rs`

**RunCommand handler** (X action):
- Switched from sync `execute_command_policy` to async `execute_command_policy_async` with 30s timeout
- Timeout sets `timed_out: true` and `ok: false` in `ToolExecutionResult`
- Error content propagates through existing `dsl_execution_repair` path

**SearchText/SearchSymbol handlers** (S/Y actions):
- Output capped at `MAX_SEARCH_OUTPUT_CHARS = 50_000` via `truncate_search_output`
- Truncated output shows `... (truncated N more chars)` — explicit about the budget
- Full output still persisted to session artifacts via `apply_tool_result_budget` at message-append time

**New `truncate_search_output` function**:
- Truncates search results for model context while preserving full output via existing persistence
- Follows same pattern as `MAX_DSL_LIST_ENTRIES_FOR_MODEL` for list output

**New tests (5 tests)**:
- `truncate_search_output_short_content` — no truncation for small results
- `truncate_search_output_long_content` — truncation with `truncated` marker
- `truncate_search_output_boundary` — exact boundary passes through unchanged
- `truncate_tool_trace_output_short` — existing truncation still works
- `truncate_tool_trace_output_long` — existing truncation with marker

### `src/dsl/mod.rs`

- Exported `execute_command_policy_async` and `validate_command` from safety module

## Tests Added (13 new tests)

| Module | Test | What it verifies |
|--------|------|------------------|
| `safety::tests` | `validate_command_rejects_empty` | Empty string → UNSAFE_COMMAND |
| `safety::tests` | `validate_command_rejects_control_chars` | Null byte → UNSAFE_COMMAND |
| `safety::tests` | `validate_command_accepts_known` | `ls -la` → Ok(["ls", "-la"]) |
| `safety::tests` | `validate_command_rejects_pipeline` | Shell pipe → UNSAFE_COMMAND |
| `safety::tests` | `validate_command_rejects_disallowed` | `rm -rf` → UNSAFE_COMMAND |
| `safety::tests` | `validate_command_disabled_policy` | Disabled policy → UNSAFE_COMMAND |
| `safety::tests` | `execute_command_async_success` | `ls` succeeds async |
| `safety::tests` | `execute_command_async_rejects_disallowed` | Policy check before async execution |
| `safety::tests` | `execute_command_async_timeout` | Policy validation catches disallowed before exec |
| `safety::tests` | `validate_command_does_not_execute` | Pure validation, no side effects |
| `tool_loop::tests` | `truncate_search_output_short_content` | Small content passes through |
| `tool_loop::tests` | `truncate_search_output_long_content` | Large content truncated with marker |
| `tool_loop::tests` | `truncate_search_output_boundary` | Exact boundary preserved |
| `tool_loop::tests` | `truncate_tool_trace_output_short` | Terminal truncation short path |
| `tool_loop::tests` | `truncate_tool_trace_output_long` | Terminal truncation long path |

## Verification

```bash
cargo fmt --check
cargo test tool_loop::executor_contract_tests
cargo test dsl
cargo test session_flush
```

All tests pass: 971 passed, 0 failed, 2 ignored.
