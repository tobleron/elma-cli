# Task 400: DSL Repair Observation Concreteness

**Status:** pending
**Priority:** critical
**Depends on:** Task 381

## Summary

Current DSL repair observations are too generic for small models to self-correct. When the model produces invalid DSL, the repair feedback says `"INVALID_DSL\ncode: INVALID_DSL\nerror: {preview}\nexpected: valid classifier DSL"` — the model cannot infer what specific format change is needed. Small models need explicit format guidance, not generic rejection.

## Session Evidence

- `s_1777635325`: Repair feedback "INVALID_DSL error: invalid action DSL output return exactly one valid action command" — no DSL format shown, model produces same failure 3 times
- `s_1777634968`: Repair feedback "INVALID_DSL error: unquoted path in action DSL use R path=\"...\" (quoted path)" — this IS specific and was the first repair, but subsequent repairs reverted to generic "invalid action DSL output"
- `s_1777636793`: Mode classifier repair shows the raw bad output as error preview but doesn't show the expected template

## Scope

1. **Template-based repair for classifiers**: Replace `classifier_repair_observation` in `src/routing_infer.rs:255-266` with format-specific feedback that includes:
   - The exact DSL template the parser expects (e.g., `MODE choice=N label=NAME reason="..." entropy=N.N`)
   - The actual model output (truncated)
   - A single concrete difference (e.g., "Missing: 'MODE' command prefix")

2. **Template-based repair for action DSL**: Similarly upgrade action DSL repair observations in `src/dsl/` to show:
   - The specific command format that was expected (R, L, S, Y, E, X, ASK, DONE)
   - The actual output received
   - A specific fix direction

3. **Progressive repair detail**: On first repair attempt, show the specific missing/malformed element. On second attempt, show the full template with the exact field structure required. On third, simplify to the most basic form (single command, minimal fields).

4. **Avoid information overload**: Keep repair observations under 300 chars — enough for the model to see the concrete fix, not enough to cause context pollution.

## Non-Goals

- Do not add complex multi-step repair instructions.
- Do not modify the DSL parser grammar.
- Do not remove existing repair retry limits.

## Success Criteria

- [ ] Mode classifier repair shows "Expected: MODE choice=N..." with actual output
- [ ] Action DSL repair shows the specific command template expected
- [ ] Third repair attempt requests simplest possible command form
- [ ] All repair observations stay under 300 chars
- [ ] `cargo test dsl && cargo test routing_infer` passes

## Verification

```bash
cargo test --bin elma-cli dsl
cargo test --bin elma-cli routing_infer
cargo run -- --debug-trace
```
