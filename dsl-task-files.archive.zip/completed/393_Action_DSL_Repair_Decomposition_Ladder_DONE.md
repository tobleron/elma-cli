# Task 393: Action DSL Repair Decomposition Ladder

**Status:** completed
**Priority:** critical
**Depends on:** Task 378, Task 381, Task 392

## Summary

Replace generic action-DSL retry feedback with a small repair ladder. Each repair step should ask the model for one narrow correction: choose action kind, fill required fields, add block terminator, or convert prose/tool markup into native DSL.

## Session Evidence

- `s_1777591563_222339000` first produced prose and a fenced shell snippet, then `<command>ls -la AGENTS.md</command>`, then stopped with no tool evidence.
- `s_1777593578_160632000` produced `<command>\nR path="AGENTS.md"\n</command>`, then `E path="AGENTS.md"`, then prose.
- `s_1777623764_855825000` produced bare `X` and unquoted `R docs/_proposals/009-empty-result-guard.md`.

## Scope

- Add a deterministic `ActionRepairKind` from parser error plus raw-output shape.
- Add focused repair prompts/messages for: missing command body, unquoted path, missing `---END`, prose before command, provider markup wrapper, bare JSON, and wrong action for requested goal.
- Keep each repair observation one compact DSL/prose line sent as user feedback.
- Track repair count by failure family so repeated same-shape failure escalates to a simpler one-bit action-kind decision.

## Non-Goals

- Do not add keyword routing for user intent.
- Do not make the primary action parser permissive.
- Do not change `src/prompt_core.rs`.

## Success Criteria

- [ ] A bare `X` receives a repair that requests `X\ncommand\n---END`.
- [ ] An unquoted path receives a repair that requests `R path="..."`.
- [ ] A missing edit body receives a repair that explains `E path="..."\n---OLD\n...\n---NEW\n...\n---END`.
- [ ] Three repeated same-shape failures escalate to a narrower action-kind decision rather than another broad retry.

## Verification

```bash
cargo test --bin elma-cli dsl
cargo test --bin elma-cli stop_policy
```

## Completion Evidence

- `cargo test --bin elma-cli dsl` passed after focused repair tests.
- `cargo test --bin elma-cli stop_policy` passed and verifies same-family escalation after three failures.
- Runtime ordering was corrected so the current failure is counted before checking escalation.
