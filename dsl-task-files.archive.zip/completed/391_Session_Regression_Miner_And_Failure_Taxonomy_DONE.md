# Task 391: Session Regression Miner And Failure Taxonomy

**Status:** completed
**Priority:** critical
**Depends on:** Task 385, Task 387

## Summary

Build a deterministic session-audit command that scans every saved Elma session and classifies recurring failures into a compact taxonomy. This makes "revise prior sessions" repeatable instead of depending on manual `rg` passes.

## Session Evidence

- `sessions/` currently has 105 `trace_debug.log` files, 93 `reasoning_audit.jsonl` files, and 178 final-answer artifacts.
- `INVALID_DSL` appears across many late DSL sessions, including `s_1777579590_913374000`, `s_1777591563_222339000`, `s_1777593578_160632000`, and `s_1777623764_855825000`.
- Provider-style tool markup appears in older reasoning traces as `<tool_call>...</tool_call>`.
- Recent action-loop failures include `<command>ls -la AGENTS.md</command>`, `<command>\nR path="AGENTS.md"\n</command>`, bare `X`, and unquoted `R docs/_proposals/009-empty-result-guard.md`.
- Some chat sessions produced workflow-success phrasing for greetings, for example `Greeting exchanged successfully. Elma is ready...`.

## Scope

- Add a session scanner under `_scripts/` or a small Rust subcommand that reads `sessions/**/{trace_debug.log,reasoning_audit.jsonl,session.json,artifacts/*final_answer*.txt}`.
- Emit a TOML or line-oriented report with: session id, first failure signature, model, route if available, failed unit if available, and suggested owning task.
- Classify at least these failure families: `invalid_action_dsl`, `provider_markup`, `bare_action_line`, `missing_block_terminator`, `prose_before_action`, `false_success_wording`, `missing_evidence_final`, `hidden_retry_or_fallback`.
- Keep scanning read-only and offline.

## Non-Goals

- Do not summarize user private content beyond bounded failure previews.
- Do not use model calls to classify failures.
- Do not rewrite or migrate historical sessions.

## Success Criteria

- [ ] Running the scanner over `sessions/` produces a stable report in under a few seconds.
- [ ] The report identifies the two observed `<command>` failures from `s_1777591563_222339000` and `s_1777593578_160632000`.
- [ ] The report separates parser failures from execution failures.
- [ ] The report can be used by Task 385 live smoke gates as a regression baseline.

## Verification

```bash
cargo test session_regression
bash _scripts/session_regression_scan.sh sessions
```

## Completion Evidence

- `bash _scripts/session_regression_scan.sh sessions` scanned 105 sessions in 2 seconds.
- The report identified both observed `<command>` failure sessions: `s_1777591563_222339000` and `s_1777593578_160632000`.
- The report emits stable failure families, model, route, failed unit, owning task, and turn error previews.
