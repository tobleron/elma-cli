# Task 418: Concrete Repair Hints For DSL Parse Failures

**Status:** pending
**Priority:** high
**Depends on:** none

## Summary

When a 3B model produces invalid DSL, the current repair feedback says:

```
INVALID_FORMAT
Expected: valid classifier DSL
Got: <prose or partial output>
Return exactly one DSL line matching the Expected format.
```

The model doesn't understand "valid classifier DSL" — it needs the exact format. The repair should include a concrete template:

```
INVALID_DSL
Expected: MODE choice=N label=EXECUTE reason="justification" entropy=N.N
Got: choice=1 label=INSPECT reason="..." entropy=0.1
Return exactly: MODE choice=<num> label=<LABEL> reason="short reason" entropy=<0.0-1.0>
```

This task makes ALL DSL repair feedback concrete and template-based.

## Scope

- For each intel unit DSL format, add a `repair_template()` method that emits the exact expected format with placeholders.
- Replace generic `Expected: valid classifier DSL` messages with concrete `Expected: <exact format with field names>`.
- Keep the `Got: <bounded preview>` showing what the model actually produced.
- Apply to all intel units: speech act, workflow gate, mode classifier, evidence assessor, decomposition, action DSL.
- Add a bounded retry: if the concrete repair also fails, use deterministic fallback (Task 412).

## Non-Goals

- Do not change the DSL format itself.
- Do not add examples to prompts — only to repair feedback.
- Do not modify src/prompt_core.rs.

## Success Criteria

- [ ] Every DSL repair message includes the exact expected format with field names.
- [ ] 3B models produce correct DSL on the second attempt after concrete repair for basic prompts.
- [ ] Generic "valid classifier DSL" or "valid intel_record" messages are eliminated.
- [ ] Repair templates render automatically from the DSL contract, not manually maintained.

## Verification

```bash
cargo build
cargo test dsl
cargo test routing_infer
cargo test intel_units
cargo run -- --debug-trace
```
