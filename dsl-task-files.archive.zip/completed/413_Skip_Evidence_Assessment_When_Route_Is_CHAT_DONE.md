# Task 413: Skip Evidence Assessment When Route Is CHAT

**Status:** completed
**Priority:** medium
**Depends on:** none

## Summary

The evidence need assessor runs for every turn, including CHAT-only greetings and self-identity questions. For "hey" and "who are you?", it returns `needs_evidence=true` — but since the route is already CHAT, this value is ignored. This wastes an LLM call (~700 bytes each) and creates inconsistency between the evidence signal and the actual route taken.

## Scope

- In the orchestration pipeline, skip the evidence_need_assessor intel unit entirely when the route is already CHAT.
- CHAT by definition does not require tools or evidence, so the assessment is redundant.
- Ensure the evidence_required flag defaults to `false` when the assessor is skipped (since CHAT doesn't need evidence).

## Non-Goals

- Do not change the evidence_need_assessor prompt.
- Do not skip evidence assessment for non-CHAT routes (SHELL, PLAN, etc.).

## Success Criteria

- [ ] Evidence assessor is not called for CHAT-only turns ("hey", "who are you?").
- [ ] Evidence assessor still runs for SHELL/WORKFLOW/PLAN routes.
- [ ] Token usage decreases for simple greetings.

## Verification

```bash
cargo build
cargo test orchestration
cargo test routing
```
