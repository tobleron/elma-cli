# T389: Restore Evidence-Grounded Final Summary In DSL DONE Action Path

**Status:** pending
**Priority:** high
**Depends on:** None (separate regression from DSL migration wave)

## Summary

The compact DSL migration replaced the old `summary` tool call mechanism with the `DONE { summary }` action. However, the `DONE` handler bypasses the evidence-grounded `run_final_summary_intel` that was previously called during the `summary` tool path. The model's raw `DONE` summary is now used directly as the final answer, which can produce incomplete or ungrounded responses.

## Root Cause

### File: `src/tool_loop.rs`

**Old path (still exists but dead code, lines 1671-1714):**
The `summary` tool call handler calls `run_final_summary_intel` (line 1682) which runs a dedicated intel unit that:
- Reads the evidence ledger
- Compares the model's draft with the original user request
- Generates a 1-2 sentence evidence-grounded summary

**New path (line 1155-1172):**
The `DONE` action directly returns the model's raw summary:
```rust
AgentAction::Done { summary } => {
    ...
    return Ok(ToolLoopResult {
        final_answer: normalize_final_answer_candidate(&summary),
        ...
    });
}
```

No evidence-ledger grounding, no cross-check against the original request.

### File: `src/tool_loop.rs` lines 2296-2346

`run_final_summary_intel` is still defined and functional. It calls `execute_intel_text_from_user_content` with the original user request, evidence ledger summaries, and the model's draft. It's just never reached from the DSL `DONE` path.

### Broader Issue

The same bypass of the summarizer affects several other tool loop exit paths:
- Line 1062: Empty DSL after evidence → `build_fallback_from_recent_tool_evidence` (no summarizer)
- Line 1110: Invalid action DSL after evidence → fallback (no summarizer)
- Line 1422-1434: Stagnation finalization → `request_final_answer_from_evidence` or `request_final_answer_without_tools` (no summarizer)

Only the old `summary` tool path (now dead code) calls `run_final_summary_intel`.

## Scope

### Fix: Wire final summary intel into the DONE action handler

- At `src/tool_loop.rs` line 1155-1172, around the `AgentAction::Done { summary }` match arm:
  - Call `run_final_summary_intel(args, client, summarizer_cfg, &original_user_request, &summary).await`
  - If the intel returns a summary, use it as the `final_answer`
  - If it fails (None), fall back to `normalize_final_answer_candidate(&summary)` as before
- This requires passing `args`, `client`, `summarizer_cfg`, and `original_user_request` to the DONE handler scope (they're already in scope at that point in the function — check lines 905-920 for the variables).
- Optionally wire the same intel into the other exit paths that produce final answers from evidence.

### Trace artifact improvement

- Add a trace log line when `run_final_summary_intel` is called from the `DONE` path, recording the original summary and the summarized version so audit logs can verify the summarizer ran.

## Non-Goals

- Do not modify `src/prompt_core.rs` or `TOOL_CALLING_SYSTEM_PROMPT`.
- Do not return to JSON model output.
- Do not add new intel units or profiles.
- Do not change the action DSL grammar.

## Success Criteria

- [ ] The `DONE` action produces an evidence-grounded 1-2 sentence summary
- [ ] The summary references the user's original request
- [ ] The evidence ledger summaries are included in the summarizer narrative
- [ ] If the summarizer fails, the fallback (raw `DONE` summary) is still used
- [ ] Trace logs show `final_summary_intel` ran from the DONE path
- [ ] `cargo test` passes

## Verification

```bash
cargo build
cargo test tool_loop
cargo test intel
cargo run -- --debug-trace
```

Manual: Run a prompt that triggers `DONE` and verify the final answer is grounded in the evidence ledger.
