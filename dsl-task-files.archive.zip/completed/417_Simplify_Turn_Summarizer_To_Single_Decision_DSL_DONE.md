# Task 417: Simplify Turn Summarizer To Single-Decision DSL

**Status:** pending
**Priority:** high
**Depends on:** Task 411

## Summary

The turn_summarizer intel unit currently asks a 3B model to produce a multi-field DSL: `summary_narrative`, `status_category`, `noteworthy`, `tools_used`, `tool_call_count`, `errors`, `artifacts_created`. This is too many fields for one call. The model frequently produces prose instead of valid DSL, or hallucinates field values.

Since Task 411 already pre-fills `tools_used`, `tool_call_count`, and other factual fields from the execution trace, the model should only produce:
1. `summary_narrative` — one compact sentence describing what happened
2. `status_category` — completed | partial | failed

Everything else is pre-filled by Rust from the execution trace after the model returns.

## Scope

- Strip the turn_summarizer DSL output to two fields: `summary_narrative` and `status_category`.
- Remove `noteworthy`, `tools_used`, `tool_call_count`, `errors`, `artifacts_created` from the model-asked DSL.
- Populate removed fields from execution trace in the `TurnSummaryOutput` Rust struct before saving to session.json.
- Update the summarizer system prompt to emit only `TURN summary_narrative="..." status_category=completed|partial|failed`.
- Ensure fallback still works with the two-field format.

## Non-Goals

- Do not change how turn summaries are saved or applied.
- Do not remove any fields from session.json metadata — only change who produces them (model vs Rust).
- Do not modify src/prompt_core.rs.

## Success Criteria

- [ ] Turn summarizer produces valid two-field DSL on 3B models without fallback.
- [ ] session.json metadata contains correct tools_used, tool_call_count, errors, artifacts.
- [ ] No instance of model-hallucinated tool counts or error lists in session.json.
- [ ] The "I'm repeating the same action type" prose-only failure never appears as summary_narrative.

## Verification

```bash
cargo build
cargo test session
cargo test intel_units
cargo run -- --debug-trace
```
