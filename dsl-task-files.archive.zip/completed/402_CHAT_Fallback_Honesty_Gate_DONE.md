# Task 402: CHAT Fallback Honesty Gate — No Hallucinated Tool Results

**Status:** pending
**Priority:** critical
**Depends on:** Task 395 (transcript visibility), T401 (mode classifier fix)

## Summary

When the mode classifier DSL parse fails and the system falls back to CHAT route (`conservative_chat_fallback` or `mode:dsl_parse_failed`), the CHAT prompt has no tools available and no executed evidence. The model, prompted to be helpful, fabricates tool-like outputs: fake directory listings, invented file contents, hallucinated search results. This creates semantic continuity failure — the user asked for real data and got fabrication.

## Session Evidence

- `s_1777636793`: User types "ls current directory and show me results" → mode DSL fails → CHAT fallback → model responds:
  ```
  Current directory: /path/to/current/directory
  Contents:
  file1.txt
  file2.txt
  subdirectory/
    file3.txt
    subsubdirectory/
      file4.txt
  ```
  This is 100% hallucinated. No tool was executed.

## Scope

1. **Detect DSL-failure fallback**: In `src/routing_infer.rs` or `src/app_chat_loop.rs`, when the route decision source contains `dsl_parse_failed` or `conservative_chat_fallback`, flag the turn as "degraded CHAT".

2. **Inject honesty preamble**: Before the CHAT prompt, inject a brief system message:
   ```
   NOTE: Tool execution was unavailable for this turn due to a format error.
   If the user asked for real information (files, search, commands), state honestly
   that you could not execute the action. Do not invent file listings, directory contents,
   or command output.
   ```

3. **Degraded finalization**: When a degraded CHAT turn ends, ensure the final answer:
   - Does not claim any tool was executed
   - Does not present invented data as real
   - States the limitation clearly if the user requested actionable output

4. **Transcript visibility**: Add a collapsible row showing "Route fallback: CHAT (DSL parse failed) — tool execution unavailable" so the user sees why no real action was taken.

## Non-Goals

- Do not prevent the CHAT response entirely — conversational turns still need natural replies.
- Do not add tool execution to the CHAT path.
- Do not modify `src/prompt_core.rs`.

## Success Criteria

- [ ] User asking "ls current directory" after mode DSL failure receives "I wasn't able to run that command" instead of fake directory listing
- [ ] Degraded CHAT turns are visible in transcript with the fallback reason
- [ ] Normal CHAT greetings ("hi", "who are you?") still produce natural replies unaffected
- [ ] `cargo test` passes

## Verification

```bash
cargo test --bin elma-cli routing_infer
cargo test --bin elma-cli ui_chat::tests
cargo run -- --debug-trace
# Manual: trigger DSL failure with a non-trivial prompt on llama_3.2_3b
```
