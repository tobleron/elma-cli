# Task 409: Force Stop on Repeated DSL Parse Failures in Tool Loop

**Status:** completed
**Priority:** high
**Depends on:** none

## Summary

The tool loop tracks `consecutive_dsl_failures` in `src/stop_policy.rs:324-328` and has a `max_repeated_dsl_failures: 3` field in `StageBudget` (line 48). However, the session trace shows the model produced multiple INVALID_DSL outputs (unquoted path, JSON wrapper, missing field) and the loop continued running, with repair feedback fed back to the model that didn't self-correct.

Check whether `max_repeated_dsl_failures` is actually enforced as a stop condition in the loop body at `src/tool_loop.rs:859-988`. If it's tracked but not acted upon, enforce it.

## Scope

- Verify `max_repeated_dsl_failures` is checked in `is_struggling()` or the tool loop body.
- If not enforced, add a stop check in the tool loop after `consecutive_dsl_failures >= max_repeated_dsl_failures`.
- When stopping on repeated DSL failures, surface the reason clearly in the transcript.
- Consider: after 3 consecutive DSL parse failures, should the system fall back to a simplified prompt or just produce a "I'm having trouble understanding" message?

## Non-Goals

- Do not change the DSL format or the parser itself.
- Do not change how repair feedback is generated.

## Success Criteria

- [ ] Loop stops after `max_repeated_dsl_failures` (3) consecutive parse failures.
- [ ] Stop reason is surfaced in the transcript.
- [ ] User receives a clear message rather than silent loop.

## Verification

```bash
cargo build
cargo test stop_policy
cargo test tool_loop
```
