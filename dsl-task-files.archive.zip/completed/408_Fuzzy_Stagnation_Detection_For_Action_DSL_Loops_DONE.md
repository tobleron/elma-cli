# Task 408: Fuzzy Stagnation Detection for Action DSL Loops

**Status:** completed
**Priority:** high
**Depends on:** Task 407

## Summary

Current stagnation detection compares exact action DSL text. When the model alternates between `L path="." depth=1` and `L path="docs/_directives" depth=1`, the stagnation counter resets because the text differs. The detector should recognize that the same action type producing the same output (or no new information) across cycles constitutes stagnation.

## Scope

- Modify `record_stagnation()` and `record_new_signals()` in `src/stop_policy.rs` to treat same action type + identical output hash as stagnation, not progress.
- Track the hash of the last N action outputs. If the same action type produces the same output repeatedly, count it as stagnation.
- Since output for `L path="."` and `L path="docs/_directives"` may differ (different directory contents), the key insight is: same action type across consecutive iterations without new evidence = stagnation, regardless of path variation.

## Non-Goals

- Do not change how the tool loop executes actions.
- Do not add semantic understanding of what actions "mean."

## Success Criteria

- [ ] Alternating `L path="."` and `L path="docs/_directives"` is detected as stagnation within 3 cycles.
- [ ] Legitimate directory exploration (different directories producing meaningfully different output) does not trigger false stagnation.
- [ ] Existing stagnation tests pass or are updated.

## Verification

```bash
cargo build
cargo test stop_policy
cargo test tool_loop
```
