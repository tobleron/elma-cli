# Task 397: Tool Orchestration Coverage Matrix

**Status:** completed
**Priority:** high
**Depends on:** Task 392, Task 393

## Summary

Create an explicit matrix from available tools to action DSL support, safety policy, transcript visibility, evidence recording, and repair behavior. This prevents Elma from having tools installed that the action loop cannot reliably orchestrate.

## Tool Coverage Matrix

| Tool | Registry State | DSL Cmd | Parser | Exec Adapter | Provider Exec | Permission Policy | Prior Read Req | Transcript | Evidence | Output Budget | Self-Test | Risk |
|------|---------------|---------|--------|-------------|---------------|------------------|---------------|------------|----------|--------------|-----------|------|
| **shell** | default | `X` | ✅ `action.rs` | ✅ `tool_loop.rs:1015-1021` | ✅ `tool_calling.rs:128-362` | preflight+perm+budget+hooks | — | ✅ ToolStarted/Finished | ✅ Shell cmd+exit_code | ✅ `apply_tool_result_budget` | ✅ registry | ExternalProcess |
| **read** | default | `R` | ✅ `action.rs` | ✅ `tool_loop.rs:977-982` | ✅ `tool_calling.rs:364-421` | workspace path validation | — | ✅ ToolStarted/Finished | ✅ Read path | ✅ | ✅ registry | ReadOnly |
| **search** | default | `S`/`Y` | ✅ `action.rs` | ✅ `tool_loop.rs:990-1000` | ✅ `tool_calling.rs:423-495` | — | — | ✅ ToolStarted/Finished | ✅ Search pattern+path | ✅ | ✅ registry | ReadOnly |
| **respond** | default | `DONE`¹ | ✅ `action.rs` | ✅ `tool_loop.rs:975-976` | ✅ `tool_calling.rs:497-517` | — | — | ✅ ToolFinished | ❌ skipped in `record_evidence` | ✅ | ✅ registry | ConversationState |
| **summary** | default | `DONE`¹ | ✅ `action.rs` | ✅ `tool_loop.rs:975-976` | ✅ `tool_calling.rs:519-537` | — | — | ✅ ToolFinished | ❌ skipped (no mapping) | ✅ | ✅ registry | ConversationState |
| **update_todo_list** | default | — | — | — | ✅ `tool_calling.rs:609-713` | — | — | ✅ ClaudeMessage::ToolResult | ❌ skipped in `record_evidence` | — | ✅ registry | WorkspaceWrite |
| **tool_search** | default | — | — | — | ✅ `tool_calling.rs:539-592` | — | — | ✅ ToolResult | ❌ skipped in `record_evidence` | — | ✅ registry | ReadOnly |
| **edit** | decl-only² | `E` | ✅ `action.rs` | ✅ `tool_loop.rs:1002-1013` | ❌ | — | ✅ `requires_prior_read` | ✅ via DSL path | ✅ via execute_agent_action | ✅ via apply_tool_result_budget | ✅ tool_registry | WorkspaceWrite |
| **ls** | decl-only² | `L` | ✅ `action.rs` | ✅ `tool_loop.rs:984-988` | ❌ | workspace path validation | — | ✅ via DSL path | ✅ via execute_agent_action | ✅ via apply_tool_result_budget | ✅ tool_registry | ReadOnly |
| **write** | decl-only² | — | — | — | ❌ | — | — | — | — | — | ✅ tool_registry | WorkspaceWrite |
| **glob** | decl-only² | — | — | — | ❌ | — | — | — | — | — | ✅ tool_registry | ReadOnly |
| **fetch** | decl-only² | — | — | — | ❌ | — | — | — | — | — | ✅ tool_registry | Network |
| **patch** | decl-only² | — | — | — | ❌ | — | — | — | — | — | ✅ tool_registry | WorkspaceWrite |

¹ respond/summary map to `DONE` via the XML/ToolCall adapter (`tool_call_xml.rs:210-218`), not a dedicated DSL command.

² `DeclarationOnly` tools are registered in the registry but **not** returned by `default_tools()`, `get_tools()`, or `search_and_convert()`. They are invisible to the model and cannot be invoked as provider tool calls.

### Legend

| Column | Meaning |
|--------|---------|
| **Registry State** | `default` = in `default_tools()` (auto-exposed to model); `decl-only` = registered but hidden |
| **DSL Cmd** | The action DSL short command (R, L, S, Y, E, X, ASK, DONE) |
| **Parser** | DSL command has a parser in `dsl/action.rs` |
| **Exec Adapter** | Has an execution handler in `tool_loop.rs::execute_agent_action()` |
| **Provider Exec** | Has an executor in `tool_calling.rs::execute_tool_call()` |
| **Permission Policy** | Safety gates applied (preflight, permission gate, budget, hooks) |
| **Prior Read Req** | Tool requires a prior read of the target before execution |
| **Transcript** | Visible in the transcript (ToolStarted/Finished, ClaudeMessage, etc.) |
| **Evidence** | Recorded in `evidence_ledger` via `record_evidence_for_tool_result()` |
| **Output Budget** | Subject to `apply_tool_result_budget()` in `tool_result_storage.rs` |
| **Self-Test** | Has unit tests in the registry or its own module |

## Key Findings

### Gaps Identified

1. **Missing evidence coverage for conversation tools** — `respond`, `summary`, `update_todo_list`, and `tool_search` are explicitly skipped by `record_evidence_for_tool_result()` (line 1073 of `tool_loop.rs`). This is intentional (these tools produce no durable evidence for factual claims), but the gap is undocumented and could regress silently.

2. **No DSL commands for `update_todo_list` or `tool_search`** — These tools are exposed as provider-native tool calls only. The model cannot invoke them via the compact DSL. This is acceptable for now because:
   - `tool_search` is a bootstrap/discovery tool used once per session
   - `update_todo_list` has complex structured arguments (action+id+text+reason) that don't map cleanly to a DSL line
   - Consider adding `T add="..."` / `T done=N` commands if models struggle with the JSON-only interface

3. **`write`, `glob`, `fetch`, `patch` are inert declarations** — They exist in the registry with `DeclarationOnly` state, are never sent to the model, and cannot be invoked. They serve as documentation/blueprints for future implementation. This is correct — they should remain hidden until DSL commands and execution adapters are implemented.

4. **No transcript visibility for `update_todo_list` results** — The tool has its own `ClaudeMessage::ToolResult` path (bypassing the standard `emit_tool_result`), so results are visible but not through the standard tool lifecycle events.

### Unsupported Tool Exposure Decision

- **write, glob, fetch, patch** — Keep `DeclarationOnly` + `.not_deferred()`. These tools remain registered (for config/query purposes) but are excluded from `default_tools()` by the `DeclarationOnly` filter. They are also excluded from `search_and_convert()` by the same filter. The model never sees them.

- **edit, ls** — Keep `DeclarationOnly` + `.not_deferred()` but with DSL coverage (E and L commands, execution adapters). The model accesses these through DSL, not provider tool calls.

- **No new tools should be added to `default_tools()` without** (a) a DSL command or (b) a provider executor. The certification test enforces this.

## Success Criteria

- [x] Every exposed tool has an owning action contract or is explicitly marked unavailable to the tool loop.
- [x] Missing transcript/evidence/safety coverage is visible in the matrix.
- [x] CI or certification can fail on accidental tool exposure without DSL support.

## Verification

```bash
cargo test --bin elma-cli tool_orchestration
cargo test --bin elma-cli tool_registry
cargo test --bin elma-cli dsl
cargo test -p elma-tools
```

## Completion Evidence

- `cargo test --bin elma-cli tool_orchestration` passed.
- `cargo test --bin elma-cli tool_registry` passed.
- `cargo test --bin elma-cli dsl` passed.
- `cargo test -p elma-tools` passed.
