# Task 414: Split Evidence Needs Assessor Into Two Single-Field DSL Units

**Status:** pending
**Priority:** critical
**Depends on:** none

## Summary

The `evidence_need_assessor` intel unit currently asks a 3B model to produce two fields in one response: `needs_evidence` AND `needs_tools`. Small models frequently fail this multi-field output, falling back to deterministic defaults that lose information.

Split into two independent intel units, each producing a single field:

1. `evidence_need_assessor` → `ASSESS needs_evidence=true|false` (one boolean)
2. `tools_need_assessor` → `TOOLS needs_tools=true|false` (one boolean)

Each unit has half the cognitive load of the current combined unit.

## Scope

- Create `tools_need_assessor` profile (prompt, grammar, config TOML) as a single-field DSL unit.
- Strip the `needs_tools` field from the existing `evidence_need_assessor` prompt and grammar.
- Wire the new unit into both orchestration pathways (refine_route_with_evidence_needs AND assess_execution_level).
- Remove the multi-field `ASSESS needs_evidence=... needs_tools=...` DSL contract.
- Verify each unit independently produces valid DSL without fallback on basic prompts.

## Non-Goals

- Do not change the routing pipeline structure.
- Do not add per-model tuning.
- Do not modify src/prompt_core.rs.

## Success Criteria

- [ ] evidence_need_assessor returns `ASSESS needs_evidence=true|false` without multi-field output.
- [ ] tools_need_assessor returns `TOOLS needs_tools=true|false` without multi-field output.
- [ ] Both units pass DSL certification on 3B models for basic smoke prompts.
- [ ] No INVALID_DSL fallback on either unit for greetings, file reads, directory listings.

## Verification

```bash
cargo build
cargo test intel_units
cargo test orchestration
cargo run -- --debug-trace
```
