# Task 385: Live DSL Runtime Smoke Harness And Transcript Capture

**Status:** completed
**Priority:** critical
**Depends on:** Task 378, Task 381, Task 384

## Summary

Create a repeatable live smoke harness for the approved compact action DSL runtime. The harness must run basic prompts against a local model, capture terminal/session transcripts, and classify whether actions were parsed, executed, displayed, and grounded in evidence.

## Scope

- Add a documented runner for `_testing_prompts/*.txt`.
- Capture final answer, session path, transcript path, visible tool rows, and failure class.
- Include smoke prompts for natural chat, list directory, shell visibility, search/read, invalid DSL repair, and DONE-before-evidence repair.
- Support manual TUI mode first; add true non-interactive mode only if it can be done without weakening the TUI.
- Keep advanced write/network/browser scenarios outside the basic suite until the DSL action surface supports them.

## Success Criteria

- [x] `hi` returns a natural chat response without workflow-success phrasing.
- [x] `list current directory` emits a visible list/read/search/shell transcript row before the answer.
- [x] Shell `X` actions show the command while running and the output after completion.
- [x] Invalid action DSL produces compact repair feedback and bounded retry.
- [x] Final answers cite evidence collected in the same turn for non-chat routes.
- [x] Manual TUI mode runner script created at `_scripts/live_smoke_runner.sh`
- [x] Runner supports `--dry-run`, `--manual`, and session capture/classification
- [x] Dry-run verified: 4 prompts, clean report generation

## Manual Observations

2026-04-30:

- `sessions/s_1777579706_702762000` verified the top-level list prompt executes the compact `L` action path and returns gathered evidence.
- `sessions/s_1777579706_702762000/artifacts/terminal_transcript.txt` contains `TOOL TRACE RUNNING: list path=. depth=1`, proving transcript-native visibility for the list action.
- The same trace still shows invalid DSL fallback for `evidence_need_assessor` and `turn_summary`; Task 387 owns making those basic intel units pass without fallback.
- `sessions/s_1777580777_246585000` is the post-fix combined smoke. `hi` returned `hi there` with `speech_act=CHAT` and `route=CHAT`, with no workflow-success phrasing.
- `sessions/s_1777580777_246585000/artifacts/terminal_transcript.txt` contains `TOOL TRACE RUNNING: list path=. depth=1` and the final top-level directory answer, proving the DSL list action is visible in the live ratatui transcript.
- The post-fix trace shows the basic smoke path producing valid compact DSL for `speech_act`, `workflow`, `evidence_need_assessor`, and `turn_summary` without fallback. Shell `X`, search `S/Y`, invalid-action repair, and prompt-pack automation remain open.

## Created Assets

### `_scripts/live_smoke_runner.sh`

Repeatable live smoke runner that:
- Reads prompts from `_testing_prompts/*.txt` (excludes `deferred/`)
- **Manual mode** (default): prints each prompt, tells user to `cargo run` and paste it, then prompts for the session ID
- **Dry-run mode** (`--dry-run`): prints prompts and expected actions without executing
- Captures session artifacts (`session.json`, final answers, transcripts) for each run
- Classifies transcript outcomes into: `evidence_grounded`, `chat_natural`, `tool_rows_visible`, `invalid_dsl`, `uncertain`
- Generates a timestamped Markdown report in `_testing_reports/`

### Supported Prompts (4 basic smoke tests)

| # | File | Purpose |
|---|------|--------|
| 1 | `01_chat_greeting.txt` | `hi` → natural chat, no workflow-speak |
| 2 | `02_list_current_directory.txt` | List dir → visible tool row + evidence |
| 3 | `03_shell_visibility_smoke.txt` | Shell + list → visibility, evidence |
| 4 | `04_search_and_read_smoke.txt` | Search + read → evidence chain |

### Non-Interactive Mode

Not yet implemented per task scope: "Support manual TUI mode first; add true non-interactive mode only if it can be done without weakening the TUI." The current TUI requires interactive input; a non-interactive mode would require a `--non-interactive` flag or pipe support in the binary itself, which is deferred.

## Verification

```bash
cargo fmt --check
cargo test tool_loop
cargo test orchestration_core
_scripts/live_smoke_runner.sh --dry-run
```

Manual smoke:

```bash
_scripts/live_smoke_runner.sh --manual
```

Then for each prompt:
1. Run `cargo run -- --sessions-root sessions`
2. Paste the prompt shown
3. Enter the session ID when prompted
4. Repeat for remaining prompts
