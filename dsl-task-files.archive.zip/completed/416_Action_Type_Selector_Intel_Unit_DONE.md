# Task 416: Action Type Selector Intel Unit

**Status:** pending
**Priority:** high
**Depends on:** none

## Summary

When the tool loop needs the model to choose an action, the current prompt asks it to both decide the action AND format it into DSL in a single response. This is two cognitive jobs in one call.

Split into:
1. **Action type selector** (this task): Given user intent, available actions, and current evidence, choose ONE action type letter (R, L, S, Y, X, E, DONE, ASK).
2. **Format specialist** (Task 415): Given the action type and arguments, produce exact DSL.

This task creates the selector unit. The format specialist is separate (Task 415) because formatting into exact syntax is a distinct cognitive job.

## Scope

- Add `ActionSelector` intel unit with prompt: "Choose exactly one action type for this turn."
- Input: user request, current objective, last evidence, available action types.
- Output: a single DSL line: `SELECT action=R reason="short justification"` (one field, one choice).
- Wire the selector into the tool loop before the format specialist.
- Remove action type selection from the current action DSL prompt.

## Non-Goals

- Do not change the action types or their semantics.
- Do not add JSON or keyword routing.
- Do not modify src/prompt_core.rs.

## Success Criteria

- [ ] Action selector reliably picks correct action type on 3B models.
- [ ] DSL output from selector is always valid single-field DSL (never INVALID_DSL).
- [ ] Combined with format specialist (Task 415), the tool loop produces valid executable actions.
- [ ] No increase in action type mis-selection compared to combined approach.

## Verification

```bash
cargo build
cargo test intel_units
cargo test tool_loop
cargo run -- --debug-trace
```
