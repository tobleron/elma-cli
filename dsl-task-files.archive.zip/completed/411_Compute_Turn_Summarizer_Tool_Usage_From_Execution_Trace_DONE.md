# Task 411: Compute Turn Summarizer Tool Usage From Execution Trace, Not Model Guess

**Status:** completed
**Priority:** medium
**Depends on:** none

## Summary

The turn_summarizer intel unit is asked to report `tools_used` and `tool_call_count` in its DSL output. The model hallucinates these values: every turn in the session claims `tools_used="read,bash" tool_call_count=4`, even for pure CHAT turns where zero tools were executed.

The Rust execution trace already knows the correct values (e.g., `tool_calling_pipeline: answer_len=30 iterations=1 tool_calls=0`). These values should be pre-filled into the summarizer prompt rather than asking the model to guess them.

## Important Clarification

This is about **session.json metadata**, not terminal display. Tool commands already appear in the user's terminal via `ToolStarted`/`ToolFinished` transcript rows. This task fixes the internal audit record.

## Scope

- In the turn_summarizer invocation site, collect the actual tool names and count from the execution trace.
- Inject them into the summarizer prompt as `TOOLS USED: <comma-separated>` and `TOOL CALL COUNT: <number>`, with clear instruction to use these values verbatim.
- Alternatively, skip asking the model for these fields entirely and populate them from Rust after the model returns its summary_narrative and status_category.

## Non-Goals

- Do not change how tools are displayed to the user.
- Do not change the turn_summarizer DSL format.

## Success Criteria

- [ ] CHAT-only turns record `tools_used="" tool_call_count=0` in session.json.
- [ ] Turns with actual tool calls record the correct tool names and counts.
- [ ] Session metadata is accurate and auditable.

## Verification

```bash
cargo build
cargo test session
```
