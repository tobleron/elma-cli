# Task 412: Deterministic Fallback on Repeated Classifier DSL Parse Failure

**Status:** pending
**Priority:** medium
**Depends on:** none

## Summary

When a classifier intel unit (workflow mode, etc.) produces malformed DSL, the system feeds a repair observation back and retries once. The session traces show the second attempt often produces the same malformed output — the small model doesn't understand the generic "expected: valid classifier DSL" repair hint and repeats its mistake.

Example: mode classifier for "who are you?" produced `choice=1 label=INSPECT reason="User asks about identity" entropy=0.1` (missing `MODE` prefix). The repair hint was `expected: valid classifier DSL` which doesn't include the specific format. The retry also failed.

## Scope

- After the first DSL parse failure + one repair retry, use deterministic fallback instead of relying on the model to self-correct.
- Fallback rules:
  - If speech_act = INSTRUCT, default mode = EXECUTE
  - If speech_act = INQUIRE, default mode = INSPECT
  - If speech_act = CHAT, default mode = DECIDE
- Surface the fallback in the transcript as a collapsible row (per AGENTS.md rule 7).
- Improve the repair hint for the retry attempt to include a concrete example: `expected: MODE choice=N label=EXECUTE reason="..." entropy=N.N`.

## Non-Goals

- Do not change the classifier DSL format.
- Do not add per-model tuning.

## Success Criteria

- [ ] Mode classifier never produces INVALID_DSL after 2 attempts (one retry + fallback).
- [ ] Fallback is surfaced in the terminal transcript.
- [ ] Repair hint includes a concrete example format.

## Verification

```bash
cargo build
cargo test routing_infer
cargo test intel_units
```
