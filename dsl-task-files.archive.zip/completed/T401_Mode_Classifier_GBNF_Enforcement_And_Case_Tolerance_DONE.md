# Task T401: Mode Classifier GBNF Enforcement And Case Tolerance

**Status:** pending
**Priority:** critical
**Depends on:** Task 380, Task 382

## Summary

The mode classifier is the most frequent DSL failure point across all live sessions. The model consistently emits `choice=2 label=EXECUTE...` without the `MODE` command prefix, or uses lowercase `mode` (both rejected by `is_command_token` which requires uppercase). A GBNF grammar exists in `config/grammars/mode_router.dsl.gbnf` and a builtin grammar exists in `json_grammar.rs:144`, but live sessions prove the grammar is not being enforced by the llama.cpp server endpoint.

## Session Evidence

- `s_1777636793`: `choice=1 label=INSPECT...` → INVALID_DSL; retry `mode choice=2 label=EXECUTE...` → still INVALID_DSL
- `s_1777635325`: `choice=5 label=DECIDE...` → INVALID_DSL
- `s_1777634968`: `choice=1 label=INSPECT...` → INVALID_DSL; retry `mode choice=2 label=EXECUTE...` → still INVALID_DSL

All three sessions show the active model is `llama_3.2_3b_instruct_q6_k_l.gguf`.

## Scope

1. **Investigate why GBNF is not enforced**: Trace whether the `grammar` field reaches the llama.cpp `/v1/chat/completions` endpoint and whether llama.cpp-server actually enforces it for this model/quantization.

2. **Case-tolerant command token fallback**: Add a recovery path in `parse_classifier_candidates` that accepts the model's actual output format (`choice=N label=NAME...` without a command token) by recognizing it as a field-only DSL variant. This is a pragmatic acceptance of what the model actually produces, not a relaxation of parser strictness.

3. **Explicit format repair feedback**: Replace the generic repair observation `"expected: valid classifier DSL"` with a specific template showing the exact expected format, e.g.:
   ```
   INVALID_FORMAT
   Expected: MODE choice=N label=NAME reason="..." entropy=N.N
   Got: choice=2 label=EXECUTE reason="list current directory" entropy=0.1
   Missing: upper-case MODE command prefix
   ```

4. **Verify grammar enforcement end-to-end**: Add a test or check that confirms whether the `grammar` field is actually being enforced by the active provider, and log a health warning if not.

## Non-Goals

- Do not relax `is_command_token` universally — keep case sensitivity for all parsed DSL.
- Do not remove the GBNF grammar.
- Do not modify `src/prompt_core.rs`.

## Success Criteria

- [ ] Mode classifier no longer produces INVALID_DSL in live smoke with llama_3.2_3b
- [ ] GBNF enforcement status is confirmed and logged
- [ ] Repair feedback shows exact expected format vs actual output
- [ ] The mode classifier parse either succeeds via grammar enforcement OR succeeds via field-only fallback recognition
- [ ] `cargo test routing_infer` passes

## Verification

```bash
cargo test --bin elma-cli routing_infer
cargo test --bin elma-cli dsl
cargo run -- --debug-trace
# Manual: run _testing_prompts/02_list_current_directory.txt
```
