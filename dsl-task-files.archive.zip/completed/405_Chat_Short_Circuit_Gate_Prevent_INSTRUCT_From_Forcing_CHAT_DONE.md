# Task 405: Chat Short-Circuit Gate – Prevent INSTRUCT From Forcing CHAT Route

**Status:** completed
**Priority:** critical
**Depends on:** none

## Summary

The `should_short_circuit_chat_route()` function in `src/routing_infer.rs` can short-circuit to CHAT even when the speech act classifier returns INSTRUCT (a shell command). The short-circuit currently only checks that both speech_act and workflow label match "CHAT", not whether the speech act classification is actually correct or confident.

Live session evidence: user typed "ls current directory and show me results". Speech act classified as CHAT (wrongly, with entropy=0.80 and margin=0.00), workflow also returned CHAT (with confidence), so short-circuit fired. The model hallucinated a directory listing instead of running `ls`.

## Root Cause

`src/routing_infer.rs:51-66` — `should_short_circuit_chat_route()` checks `choice_label() == "CHAT"` for both speech and workflow. When the small model misclassifies a shell command as CHAT, the short-circuit can fire and bypass the tool loop entirely.

The entropy threshold (default 0.20) *should* prevent this, but the session trace shows speech_act entropy was 0.80 for the misclassified INSTRUCT turn, suggesting the short-circuit either used different thresholds or a different code path was taken.

## Scope

- Inspect the actual routing path taken in the session trace vs `should_short_circuit_chat_route()` and the application site at `src/routing_infer.rs:461-493`.
- Add a guard: if speech_act entropy exceeds a stricter threshold OR if speech_act margin is below threshold, do not short-circuit even if workflow agrees on CHAT.
- Ensure speech_act=INSTRUCT can never be short-circuited to CHAT regardless of confidence values.
- Add a test case: INSTRUCT speech act with low-entropy CHAT workflow must NOT short-circuit.

## Non-Goals

- Do not modify `src/prompt_core.rs`.
- Do not add keyword-based routing.
- Do not change the overall routing pipeline structure.

## Success Criteria

- [ ] "ls current directory" routes to SHELL/WORKFLOW (not CHAT) and runs the actual `ls` command.
- [ ] Greetings ("hey", "hi") still route normally to CHAT.
- [ ] Existing routing tests pass.

## Verification

```bash
cargo test routing_infer::tests
cargo test routing
cargo build
```
