# T388: Restore Thinking Streaming And Terminal Command Display In DSL Tool Loop

**Status:** pending
**Priority:** critical
**Depends on:** None (regression introduced by DSL migration wave)

## Summary

Two regressions were introduced by the compact DSL migration (Wave 0):

1. **Thinking/reasoning no longer streams words in the TUI.** The tool loop forces `reasoning_format="none"` and passes `display_assistant_content=false` to the streaming handler, which suppresses ALL streaming events (ThinkingDelta, AssistantContentDelta, ThinkingStarted/Finished, AssistantFinished) from reaching the ClaudeRenderer. The old code had `reasoning_format="auto"` and no `display_assistant_content` gate — everything streamed.

2. **Terminal commands show internal tool-trace format instead of shell-like lines.** The Claude Code-style ToolTrace renderer shows `◐ shell cargo test` instead of something shell-like. The old behavior showed the command running in a way that looked like a real terminal session.

## Root Cause: Tool Loop Streaming Changes

### File: `src/tool_loop.rs`

**Line 93-96** — `ensure_tool_loop_reasoning_format` forces `reasoning_format="none"`:
```rust
fn ensure_tool_loop_reasoning_format(req: &mut ChatCompletionRequest) {
    req.reasoning_format
        .get_or_insert_with(|| "none".to_string());
}
```
Before: `req.reasoning_format = Some("auto".to_string())` (line 101 of old code)

**Line 1013** — request options explicitly set `reasoning_format: Some(Some("none".to_string()))`

**Line 1025** — streaming call passes `false` for `display_assistant_content`:
```rust
let turn = match request_tool_loop_model_turn_streaming(
    tui, client, chat_url, req.clone(), ..., false,  // display_assistant_content=false
)
```

Before: no `display_assistant_content` parameter existed — streaming was always visible.

Inside the streaming function (`tool_loop.rs` lines 98-277), when `display_assistant_content=false`:
- Lines 189-202: `reasoning_content` from API is silently accumulated, never sent as UiEvent
- Lines 214-228: `<think>`/`<thinking>`/`<reasoning>`/`<thought>` tags in content are silently accumulated
- Lines 239-248: assistant content deltas are silently accumulated
- The `ClaudeRenderer` never receives any streaming events during the tool loop model turn

### Differentiation Still Works

The reasoning/content separation logic in `src/orchestration_helpers/mod.rs` (`process_stream_content_chunk`, lines 60-121) correctly extracts `<think>/<thinking>/<reasoning>/<thought>` tags from the content stream. API-level `reasoning_content` fields are also correctly separated at lines 180-203 of the streaming handler. The logic is intact — it just never reaches the UI.

### File: `src/tool_loop.rs` (action execution, lines 1173-1252)

When DSL actions execute (`X`, `S`, `Y`, etc.), the tool loop emits `ToolStarted`/`ToolFinished` events via `UiEvent::ToolStarted` (line 1177) and `UiEvent::ToolFinished` (line 1191). These correctly reach the ClaudeRenderer.

However, the ClaudeRenderer renders these as ToolTrace messages showing tool name + command. For shell `X` commands, it shows:
```
◐ shell cargo test
```
instead of a shell-like:
```
$ cargo test
```

### File: `src/claude_ui/claude_state.rs` lines 399-470 (ratatui) and lines 733-780 (ANSI)

The ToolTrace rendering always shows the tool `name` as a bold prefix. For `name="shell"`, it should render as a `$` prefix instead.

## Scope

### Fix 1: Restore thinking streaming in the tool loop

- In `request_tool_loop_model_turn_streaming` (tool_loop.rs line 98): emit `UiEvent::ThinkingDelta` and `UiEvent::AssistantContentDelta` even during DSL tool loop turns. The accumulated content is still packaged as the turn result — the streaming display is purely for the human watching the TUI.
- Consider using `reasoning_format="auto"` or a model-behavior-aware setting instead of forcing `"none"`. The DSL migration concern (actions pushed into hidden reasoning) should be handled by the parser, not by suppressing all streaming.
- If `reasoning_format="none"` is needed for correctness, ensure that `<think>` tags embedded in the `content` field are still streamed to the UI.

### Fix 2: Restore shell-like command display

- In `src/claude_ui/claude_state.rs`, both ratatui and ANSI rendering paths: when `name == "shell"`, render the trace line as `$ <command>` instead of `shell <command>`.
- The transcript persistence in `claude_render.rs` (line 165-184) should also use `$ <command>` format for shell commands.

### Fix 3: Ensure streaming differentiation is verified

- Add a regression test or scenario that verifies thinking deltas appear in the transcript during a tool loop turn.
- Verify that final assistant output (content outside `<think>` tags) reaches the answer separately from thinking content.

## Non-Goals

- Do not modify `src/prompt_core.rs` or `TOOL_CALLING_SYSTEM_PROMPT`.
- Do not return to JSON model output.
- Do not change the action DSL parser or executor.

## Success Criteria

- [ ] During tool loop model turns, thinking/reasoning text streams word-by-word in the TUI
- [ ] Shell `X` commands show as `$ <command>` in the transcript instead of `shell <command>`
- [ ] Final assistant content is correctly separated from thinking content
- [ ] No regression in action DSL parsing or execution
- [ ] `cargo test dsl` and `cargo test tool_loop` pass

## Verification

```bash
cargo build
cargo test tool_loop
cargo test claude_ui
cargo test dsl
cargo run -- --debug-trace
```
