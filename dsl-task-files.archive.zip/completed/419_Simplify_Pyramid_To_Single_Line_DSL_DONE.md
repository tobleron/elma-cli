# Task 419: Simplify Decomposition Pyramid to Single-Line DSL

**Status:** pending
**Priority:** high
**Depends on:** none

## Summary

The decomposition pyramid intel unit asks 3B models to produce a multi-line block DSL (OBJECTIVE + GOALs + TASKs + END). Session traces show consistent failures:
- Single quotes instead of double quotes (`text='Run date command'`)
- Missing END terminator
- Truncated output halfway through

Small models cannot reliably produce block DSL with multiple line types and terminator markers. The pyramid DSL is the most complex format Elma asks for.

Simplify to a single-line DSL: `OBJECTIVE text="one-line objective" risk=low|medium|high`. This follows the same pattern as Task 417 (simplified TURN from 7 fields to 2).

The GOAL/TASK lines provide detail but are not essential for routing — the pyramid's role is to confirm that a non-trivial action plan can be extracted, not to produce a detailed plan.

## Scope

- Strip GOAL and TASK lines from the pyramid DSL format.
- Keep only `OBJECTIVE text="one-line" risk=low|medium|high` as a single-line DSL.
- Remove END terminator requirement.
- Update the narrative prompt to ask for only the OBJECTIVE line.
- Keep DecompositionPyramid struct but default goals/tasks to empty.
- Update fallback to produce single-line format.

## Non-Goals

- Do not change how the pyramid is used in orchestration.
- Do not add JSON or any alternative format.
- Do not modify src/prompt_core.rs.

## Success Criteria

- [ ] Pyramid DSL parses without INVALID_DSL on 3B models for basic prompts.
- [ ] Single quotes and missing END errors drop to zero.
- [ ] Pyramid still provides useful objective + risk classification for routing.

## Verification

```bash
cargo build
cargo test intel_units
cargo test decomposition
cargo run -- --debug-trace
```
