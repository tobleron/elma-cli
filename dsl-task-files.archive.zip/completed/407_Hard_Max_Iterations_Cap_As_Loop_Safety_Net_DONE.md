# Task 407: Hard Max Iterations Cap as Loop Safety Net

**Status:** completed
**Priority:** critical
**Depends on:** none

## Summary

The tool loop currently defaults `max_iterations: 0` (meaning unlimited). When stagnation detection fails — as it did in the "explore workspace" turn where the model alternated between `L path="."` and `L path="docs/_directives"` — the loop runs indefinitely (150+ iterations observed). A hard cap is needed as a redundant safety net.

## Why Stagnation Detection Failed

Stagnation detection in `src/stop_policy.rs:307-314` compares exact action traces. The model alternated between two different paths, which `record_new_signals()` at line 319-322 treated as "progress" and reset the stagnation counter. A hard max_iterations cap would have stopped the loop after N iterations regardless.

## Scope

- Change the default `max_iterations` in `src/stop_policy.rs:44-47` from `0` to `40`.
- Ensure the cap is enforced in `start_iteration()` at `src/stop_policy.rs:146-166`.
- When the cap is hit, produce a clear stop reason and a fallback user-facing message ("I wasn't able to complete this task after N attempts") rather than silent failure.
- Consider making this configurable via `RoutingConfig` (already has a `max_iterations` field if present).

## Non-Goals

- Do not change the stagnation detection algorithm in this task (see Task 408).
- Do not change the tool loop's overall structure.

## Success Criteria

- [ ] Default `max_iterations` is 40 (not 0/unlimited).
- [ ] Loop stops after reaching `max_iterations` with a clear stop reason.
- [ ] User receives a fallback message when the loop is capped.

## Verification

```bash
cargo build
cargo test stop_policy
cargo test tool_loop
```
