# Task 410: Dedup Current Message From Conversation History in Intent Prompts

**Status:** completed
**Priority:** high
**Depends on:** none

## Summary

The intent helper prompt includes both the conversation history AND the raw user message. When this is the first turn, the conversation history contains the same message, creating a phantom duplicate:

```
CONVERSATION HISTORY:
User: heyyyy
User: heyyyy
```

The intent model then annotates this as "The user is repeating the greeting" — a noisy, incorrect interpretation of what is actually a single message.

## Root Cause

In `src/effective_history.rs`, the conversation history construction appears to include the latest user message before the intent prompt is built. The intent prompt then separately includes the raw user message as `User message:\n{message}`. When the user's previous message is identical to the current one (common for corrected/refined prompts), the model sees the same text twice.

## Scope

- In `src/effective_history.rs` or wherever the intent helper prompt is assembled, filter out the current user message from conversation history if it appears as the last entry.
- Alternatively, truncate conversation history to exclude the current in-progress turn before passing to intent/speech-act/workflow classifiers.
- Ensure this doesn't break multi-turn context (previous turns should still be included).

## Non-Goals

- Do not change how conversation history is stored in session artifacts.
- Do not change the intent helper's output format.

## Success Criteria

- [ ] First-turn intent prompt shows `User: heyyyy` once, not twice.
- [ ] Multi-turn context still shows previous turns correctly.
- [ ] Intent annotation for "heyyyy" is "The user is greeting" not "The user is repeating the greeting".

## Verification

```bash
cargo build
cargo test effective_history
cargo test routing
```
