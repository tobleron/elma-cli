# Task 403: Action DSL Convergence — Simplify-On-Retry + Evidence Fallback

**Status:** pending
**Priority:** high
**Depends on:** Task 393 (DSL repair decomposition), Task 398 (evidence grounded finalization)

## Summary

When the action DSL loop fails to produce valid DSL after 3 repair attempts, the stop policy terminates with "I could not continue because the model repeatedly produced invalid action DSL. No workspace changes were made." This is honest but useless. The system should:
1. Simplify the request on retry (decompose complex DSL into simplest single command)
2. On final exhaustion, produce an evidence-grounded fallback answer from whatever was gathered

## Session Evidence

- `s_1777635325`: "sunnarize docs" → 3 repair failures → "I could not continue... No workspace changes were made." — user gets nothing useful
- `s_1777634968`: "where are my documents?" → 3 repair failures → same dead-end message
- The stop policy correctly detects and terminates the loop, but finalization produces zero value

## Scope

1. **Simplify-on-retry**: When the first repair attempt fails:
   - On 2nd retry: strip batch/complex DSL and ask for the simplest single command (e.g., `L path=. depth=1` or `R path="filename"`)
   - On 3rd retry: ask for `ASK reason="what should I do?"` so the model can verbalize its intent
   - The simplification ladder should be injected into the repair feedback

2. **Evidence-grounded exhaustion answer**: When the stop policy fires:
   - Build a finalization context from: user intent, route, any successfully executed tools (even if zero), stop reason
   - If zero tools executed: produce "I couldn't determine the right action. [stop_reason]. Here's what I understood: [intent]. Can you rephrase or give me more direction?"
   - If partial evidence exists: produce a bounded summary of what was found, labeled as partial

3. **Prevent empty terminate messages**: The DSL stop policy must never produce a final answer that is just "I could not continue" with zero context. Minimum: always include user intent and stop reason.

## Non-Goals

- Do not increase the retry limit beyond 3 attempts.
- Do not add new prompt machinery outside the existing DSL repair path.
- Do not modify `src/prompt_core.rs`.

## Success Criteria

- [ ] 2nd DSL repair attempt asks for simplest single command
- [ ] 3rd DSL repair attempt asks for ASK verbalization
- [ ] Exhaustion answer includes user intent, stop reason, and next-step guidance
- [ ] Partial evidence (if any) is presented as bounded summary
- [ ] `cargo test` passes

## Verification

```bash
cargo test --bin elma-cli dsl
cargo test --bin elma-cli tool_loop
cargo test --bin elma-cli stop_policy
cargo run -- --debug-trace
```
